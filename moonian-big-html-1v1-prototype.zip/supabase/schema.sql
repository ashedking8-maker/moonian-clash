-- Moonian Clash online 1v1 prototype
-- Run this in Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.match_rooms (
  id uuid primary key default gen_random_uuid(),
  status text not null default 'waiting' check (status in ('waiting', 'playing', 'finished')),
  player1_id text,
  player2_id text,
  game_state jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.match_rooms enable row level security;

drop policy if exists "match rooms are readable" on public.match_rooms;
create policy "match rooms are readable"
  on public.match_rooms
  for select
  using (true);

drop policy if exists "players can create rooms" on public.match_rooms;
create policy "players can create rooms"
  on public.match_rooms
  for insert
  with check (true);

drop policy if exists "players can update their rooms" on public.match_rooms;
create policy "players can update their rooms"
  on public.match_rooms
  for update
  using (true)
  with check (true);

drop policy if exists "waiting room owner can delete" on public.match_rooms;
create policy "waiting room owner can delete"
  on public.match_rooms
  for delete
  using (status = 'waiting');

create index if not exists match_rooms_waiting_idx
  on public.match_rooms (status, created_at)
  where status = 'waiting';

-- In Supabase Dashboard, also enable Realtime for table public.match_rooms.
