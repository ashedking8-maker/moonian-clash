import { useEffect, useMemo, useState } from 'react';
import { createGuestId, createInitialGameState, type MatchRoom, type PlayerSlot } from '../lib/onlineGame';
import { isSupabaseConfigured, supabase } from '../lib/supabaseClient';

type MatchmakingPageProps = {
  onBackToMenu: () => void;
  onMatchFound: (roomId: string, playerId: string, playerSlot: PlayerSlot) => void;
};

export function MatchmakingPage({ onBackToMenu, onMatchFound }: MatchmakingPageProps) {
  const [status, setStatus] = useState('Preparing matchmaking...');
  const [error, setError] = useState('');

  const playerId = useMemo(() => createGuestId(), []);

  useEffect(() => {
    if (!supabase || !isSupabaseConfigured) {
      setStatus('Supabase is not configured yet.');
      return;
    }

    let joinedRoomId: string | null = null;
    let cancelled = false;

    async function findOrCreateMatch() {
      setStatus('Searching for Player...');
      setError('');

      const { data: waitingRooms, error: findError } = await supabase!
        .from('match_rooms')
        .select('*')
        .eq('status', 'waiting')
        .neq('player1_id', playerId)
        .is('player2_id', null)
        .order('created_at', { ascending: true })
        .limit(1);

      if (cancelled) return;
      if (findError) {
        setError(findError.message);
        return;
      }

      const waitingRoom = waitingRooms?.[0] as MatchRoom | undefined;

      if (waitingRoom) {
        const { data: joined, error: joinError } = await supabase!
          .from('match_rooms')
          .update({
            player2_id: playerId,
            status: 'playing',
            game_state: waitingRoom.game_state ?? createInitialGameState(),
            updated_at: new Date().toISOString(),
          })
          .eq('id', waitingRoom.id)
          .is('player2_id', null)
          .select('*')
          .single();

        if (cancelled) return;
        if (joinError) {
          setError(joinError.message);
          return;
        }

        onMatchFound((joined as MatchRoom).id, playerId, 'player2');
        return;
      }

      const { data: created, error: createError } = await supabase!
        .from('match_rooms')
        .insert({
          status: 'waiting',
          player1_id: playerId,
          player2_id: null,
          game_state: createInitialGameState(),
        })
        .select('*')
        .single();

      if (cancelled) return;
      if (createError) {
        setError(createError.message);
        return;
      }

      const room = created as MatchRoom;
      joinedRoomId = room.id;
      setStatus('Waiting for Player 2... Open this app in another browser to test.');

      const channel = supabase!
        .channel(`matchmaking-${room.id}`)
        .on(
          'postgres_changes',
          { event: 'UPDATE', schema: 'public', table: 'match_rooms', filter: `id=eq.${room.id}` },
          (payload) => {
            const nextRoom = payload.new as MatchRoom;
            if (nextRoom.status === 'playing' && nextRoom.player2_id) {
              onMatchFound(nextRoom.id, playerId, 'player1');
            }
          },
        )
        .subscribe();

      return () => supabase!.removeChannel(channel);
    }

    const cleanupPromise = findOrCreateMatch();

    return () => {
      cancelled = true;
      cleanupPromise.then((cleanup) => cleanup?.());

      if (joinedRoomId) {
        supabase!
          .from('match_rooms')
          .delete()
          .eq('id', joinedRoomId)
          .eq('status', 'waiting')
          .eq('player1_id', playerId)
          .then(() => undefined);
      }
    };
  }, [onMatchFound, playerId]);

  return (
    <div className="prototypePage">
      <div className="prototypePanel">
        <h1>{status}</h1>
        <p>Online 1v1 matchmaking cez Supabase Realtime.</p>

        <div className="loadingOrb" />

        {!isSupabaseConfigured && (
          <p className="errorText">
            Missing env: VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY
          </p>
        )}

        {error && <p className="errorText">{error}</p>}

        <button className="prototypeBackBtn" onClick={onBackToMenu}>
          Cancel
        </button>
      </div>
    </div>
  );
}
