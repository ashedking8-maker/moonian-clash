type GamePageProps = {
  onBackToMenu: () => void;
};

export function GamePage({ onBackToMenu }: GamePageProps) {
  return (
    <div className="originalGamePage">
      <iframe
        className="originalGameFrame"
        src="/moonian-original.html"
        title="Moonian Clash Original Game"
      />

      <button className="originalGameBackBtn" onClick={onBackToMenu}>
        MENU
      </button>
    </div>
  );
}
