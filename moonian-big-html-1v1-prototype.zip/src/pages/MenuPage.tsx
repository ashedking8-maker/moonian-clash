import { useState } from 'react';

type Tab = 'profile' | 'inventory' | 'shop' | null;

type MenuPageProps = {
  onPlayAi: () => void;
  onPlayRandomPlayer: () => void;
};

const heroImage =
  'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgMCFxhrx0V1miizc_VOBwp5YSsA2quN-tpT4pSsAGAQYdADPhXxvzdlG5INsHtLoIF36HQjnj3hbyHfKfUuS4C920Hy62md5FNKJA6ka_WFqRITPOa-XjiCx0ogqQCDc9DLpuNcYdEzRSk/w919/miya-modena-butterfly-legend-skin-mobile-legends-4k-uhdpaper.com-171.1_a-thumbnail.jpg';

const profileImage = 'https://api.dicebear.com/8.x/adventurer/svg?seed=Ashed';

export function MenuPage({ onPlayAi, onPlayRandomPlayer }: MenuPageProps) {
  const [activeTab, setActiveTab] = useState<Tab>(null);

  function toggleTab(tab: Exclude<Tab, null>) {
    setActiveTab((current) => (current === tab ? null : tab));
  }

  return (
    <div className="gameMenu">
      <img className="bgImage" src={heroImage} alt="Background hero" />

      <div className="bgShade" />

      <div className="uiLayer">
        <header className="topBar">
          <div className="playerIdentity">
            <div className="profileBox">
              <img src={profileImage} alt="Profile" />
            </div>

            <div className="playerName">PlayerName</div>
          </div>

          <div className="navSection">
            <button
              className={activeTab === 'profile' ? 'navBtn active' : 'navBtn'}
              onClick={() => toggleTab('profile')}
            >
              PROFILE
            </button>

            <div className="navSeparator" />

            <button
              className={activeTab === 'inventory' ? 'navBtn active' : 'navBtn'}
              onClick={() => toggleTab('inventory')}
            >
              INVENTORY
            </button>

            <div className="navSeparator" />

            <button
              className={activeTab === 'shop' ? 'navBtn active' : 'navBtn'}
              onClick={() => toggleTab('shop')}
            >
              SHOP
            </button>
          </div>
        </header>

        <main className="menuContent">
          {activeTab && <section className="contentPanel" />}

          <div className="playStack">
            <button className="aiButton" onClick={onPlayAi}>
              vs AI
            </button>

            <button className="playerButton" onClick={onPlayRandomPlayer}>
              vs Player (Random)
            </button>
          </div>
        </main>
      </div>
    </div>
  );
}
