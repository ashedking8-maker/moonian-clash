import { isSupabaseConfigured } from '../lib/supabaseClient';
import type { PlayerSlot } from '../lib/onlineGame';

type OnlineGamePageProps = {
  roomId: string;
  playerId: string;
  playerSlot: PlayerSlot;
  onBackToMenu: () => void;
};

export function OnlineGamePage({ roomId, playerId, playerSlot, onBackToMenu }: OnlineGamePageProps) {
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL ?? '';
  const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY ?? '';
  const htmlSlot = playerSlot === 'player1' ? 'p1' : 'p2';

  const params = new URLSearchParams({
    online: '1',
    room: roomId,
    pid: playerId,
    slot: htmlSlot,
    supabaseUrl,
    supabaseKey,
  });

  if (!isSupabaseConfigured) {
    return (
      <div className="prototypePage">
        <div className="prototypePanel onlinePanel">
          <h1>Supabase is not configured</h1>
          <p>Add <code>VITE_SUPABASE_URL</code> and <code>VITE_SUPABASE_ANON_KEY</code> into <code>.env.local</code>.</p>
          <button className="prototypeBackBtn" onClick={onBackToMenu}>MENU</button>
        </div>
      </div>
    );
  }

  return (
    <div className="originalGamePage">
      <iframe
        className="originalGameFrame"
        src={`/moonian-online.html?${params.toString()}`}
        title="Moonian Clash Online 1v1"
        allow="fullscreen"
      />
      <button className="originalGameBackBtn" onClick={onBackToMenu}>
        MENU
      </button>
    </div>
  );
}
