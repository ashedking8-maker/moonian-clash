export type PlayerSlot = 'player1' | 'player2';

export type Fighter = {
  name: string;
  hp: number;
  maxHp: number;
  mana: number;
  power: number;
  shield: number;
};

export type OnlineGameState = {
  turn: PlayerSlot;
  round: number;
  winner: PlayerSlot | null;
  log: string[];
  player1: Fighter;
  player2: Fighter;
  mode?: string;
  startingSlot?: 'p1' | 'p2';
  __onlineHtml?: string;
  [key: string]: unknown;
};

export type MatchRoom = {
  id: string;
  status: 'waiting' | 'playing' | 'finished';
  player1_id: string | null;
  player2_id: string | null;
  game_state: OnlineGameState | null;
  created_at?: string;
  updated_at?: string;
};

export function createGuestId() {
  const storageKey = 'moonian_guest_id';
  const saved = localStorage.getItem(storageKey);
  if (saved) return saved;

  const next = crypto.randomUUID();
  localStorage.setItem(storageKey, next);
  return next;
}

export function createInitialGameState(): OnlineGameState {
  const startingSlot = Math.random() < 0.5 ? 'p1' : 'p2';

  return {
    mode: 'big-html-1v1',
    startingSlot,
    turn: startingSlot === 'p1' ? 'player1' : 'player2',
    round: 1,
    winner: null,
    log: [`Online room created. ${startingSlot === 'p1' ? 'Player 1' : 'Player 2'} starts.`],
    player1: {
      name: 'Player 1',
      hp: 30,
      maxHp: 30,
      mana: 3,
      power: 5,
      shield: 0,
    },
    player2: {
      name: 'Player 2',
      hp: 30,
      maxHp: 30,
      mana: 3,
      power: 5,
      shield: 0,
    },
  };
}
function opponentOf(slot: PlayerSlot): PlayerSlot {
  return slot === 'player1' ? 'player2' : 'player1';
}

function appendLog(state: OnlineGameState, text: string): string[] {
  return [text, ...state.log].slice(0, 8);
}

function nextTurnState(state: OnlineGameState): OnlineGameState {
  const nextTurn = opponentOf(state.turn);
  const nextRound = nextTurn === 'player1' ? state.round + 1 : state.round;
  const nextFighter = state[nextTurn];

  return {
    ...state,
    turn: nextTurn,
    round: nextRound,
    [nextTurn]: {
      ...nextFighter,
      mana: Math.min(10, nextFighter.mana + 2),
      shield: 0,
    },
  };
}

export function performAction(
  state: OnlineGameState,
  actor: PlayerSlot,
  action: 'attack' | 'guard' | 'blast' | 'endTurn',
): OnlineGameState {
  if (state.winner || state.turn !== actor) return state;

  const defender = opponentOf(actor);
  const me = state[actor];
  const enemy = state[defender];

  if (action === 'endTurn') {
    const next = nextTurnState(state);
    return {
      ...next,
      log: appendLog(state, `${me.name} ended the turn.`),
    };
  }

  if (action === 'guard') {
    const guarded: OnlineGameState = {
      ...state,
      [actor]: {
        ...me,
        mana: Math.min(10, me.mana + 1),
        shield: me.shield + 4,
      },
      log: appendLog(state, `${me.name} guarded and gained shield.`),
    };
    return nextTurnState(guarded);
  }

  const cost = action === 'blast' ? 3 : 0;
  if (me.mana < cost) return state;

  const rawDamage = action === 'blast' ? me.power + 4 : me.power;
  const damage = Math.max(0, rawDamage - enemy.shield);
  const nextHp = Math.max(0, enemy.hp - damage);
  const winner = nextHp <= 0 ? actor : null;

  const afterHit: OnlineGameState = {
    ...state,
    winner,
    [actor]: {
      ...me,
      mana: me.mana - cost,
    },
    [defender]: {
      ...enemy,
      hp: nextHp,
      shield: Math.max(0, enemy.shield - rawDamage),
    },
    log: appendLog(
      state,
      `${me.name} used ${action === 'blast' ? 'Mana Blast' : 'Attack'} for ${damage} damage.`,
    ),
  };

  return winner ? afterHit : nextTurnState(afterHit);
}
