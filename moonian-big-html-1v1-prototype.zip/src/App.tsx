import { useState } from 'react';
import './App.css';
import { MenuPage } from './pages/MenuPage';
import { MatchmakingPage } from './pages/MatchmakingPage';
import { OnlineGamePage } from './pages/OnlineGamePage';
import type { PlayerSlot } from './lib/onlineGame';

type Screen = 'menu' | 'matchmaking' | 'onlineGame';

type OnlineMatch = {
  roomId: string;
  playerId: string;
  playerSlot: PlayerSlot;
};

export default function App() {
  const [screen, setScreen] = useState<Screen>('menu');
  const [onlineMatch, setOnlineMatch] = useState<OnlineMatch | null>(null);

  if (screen === 'matchmaking') {
    return (
      <MatchmakingPage
        onBackToMenu={() => setScreen('menu')}
        onMatchFound={(roomId, playerId, playerSlot) => {
          setOnlineMatch({ roomId, playerId, playerSlot });
          setScreen('onlineGame');
        }}
      />
    );
  }

  if (screen === 'onlineGame' && onlineMatch) {
    return (
      <OnlineGamePage
        roomId={onlineMatch.roomId}
        playerId={onlineMatch.playerId}
        playerSlot={onlineMatch.playerSlot}
        onBackToMenu={() => {
          setOnlineMatch(null);
          setScreen('menu');
        }}
      />
    );
  }

  return (
    <MenuPage
      onPlayAi={() => {
        window.location.href = '/moonian-original.html';
      }}
      onPlayRandomPlayer={() => setScreen('matchmaking')}
    />
  );
}
